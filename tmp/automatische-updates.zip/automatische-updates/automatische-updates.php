<?php
/**
 * Plugin Name: Automatische Updates
 * Description: Schaltet die von STRATO „WordPress & Co.“ (Installatron) gesperrten Hintergrund-Updates wieder ein: WordPress-Sicherheitsupdates, Plugins und Übersetzungen. Große WordPress-Versionssprünge bleiben bewusst manuell.
 * Version: 1.0.0
 * Requires at least: 5.5
 * Requires PHP: 7.4
 * Author: Engel Media Consulting LLC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

// Sperre von Installatron aufheben (AUTOMATIC_UPDATER_DISABLED).
add_filter( 'automatic_updater_disabled', '__return_false', 999 );

// WordPress: nur Sicherheits- und Wartungsupdates (z. B. 7.1.4 -> 7.1.5).
add_filter( 'allow_minor_auto_core_updates', '__return_true', 999 );
add_filter( 'allow_major_auto_core_updates', '__return_false', 999 );
add_filter( 'allow_dev_auto_core_updates', '__return_false', 999 );

// Plugins und Übersetzungen automatisch.
add_filter( 'auto_update_plugin', '__return_true', 999 );
add_filter( 'auto_update_translation', '__return_true', 999 );
